#https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1217/T1217.md
#Chrome\\\\User Data\\\\Default
import shutil
import subprocess

p = subprocess.Popen(["where", "/R","C:\\Users\\","Bookmarks"], stdout=subprocess.PIPE)
out, err = p.communicate()
out =str(out)
locations = out.split("\\r\\n")

for bookmarks in locations:
    if "Chrome" in bookmarks:
        
        if"b'" in bookmarks:
            bookmarks = bookmarks[2:]
        
        #subprocess.run("notepad "+bookmarks,shell=True)
        shutil.copy(bookmarks,"Bookmarks.txt")
        subprocess.run("Bookmarks.txt",shell=True)
        break
    
